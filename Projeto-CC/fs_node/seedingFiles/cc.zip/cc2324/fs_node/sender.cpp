#include <iostream>
#include <cstring>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sstream>
#include <fstream>
#include <unordered_map>
#include <filesystem> 
#include <net/if.h>
#include <ifaddrs.h>
#include <thread>
#include <stdlib.h>
#include <atomic>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

std::string sharedFolderPath; // Change char* to std::string

std::atomic<bool> isReceiverThreadDone(false);


#define MAX_SEGMENT_SIZE 1024

int NumDigits(int x)  
{  
    x = abs(x);  
    return (x < 10 ? 1 :   
        (x < 100 ? 2 :   
        (x < 1000 ? 3 :   
        (x < 10000 ? 4 :   
        (x < 100000 ? 5 :   
        (x < 1000000 ? 6 :   
        (x < 10000000 ? 7 :  
        (x < 100000000 ? 8 :  
        (x < 1000000000 ? 9 :  
        (x < 10000000000 ? 10 :  
        (x < 100000000000 ? 11 :  
        (x < 1000000000000 ? 12 :  
        (x < 10000000000000 ? 13 :  
        (x < 100000000000000 ? 14 :  
        (x < 1000000000000000 ? 15 :  
        16)))))))))))))));  
}


void send_file(const std::string& filename, int start, int end, const std::string& ip, int port) {
    // Check if sharedFolderPath is initialized properly
    if (sharedFolderPath.empty()) {
        std::cerr << "Shared folder path is not initialized\n";
        return;
    }
    
    std::string filepath = std::string(sharedFolderPath) + filename;

    // Open the file
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Failed to open file: " << filename << std::endl;
        return;
    }

    // Seek to the start position
    file.seekg(start-1);

    int tag_size = NumDigits(start)+1; 
    // Create a UDP socket
    int udpSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udpSocket < 0) {
        std::cerr << "Failed to create socket\n";
        return;
    }

    // Configure the server address to send data
    struct sockaddr_in serverAddr;
    std::memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip.c_str(), &serverAddr.sin_addr) <= 0) {
        std::cerr << "Invalid IP address\n";
        close(udpSocket);
        return;
    }

    // Read and send the file data in chunks
    int segmentNumber = start;  // Initialize segment number        

    char buffer[MAX_SEGMENT_SIZE];
    while (start < end) {
        int bytesToRead = std::min(MAX_SEGMENT_SIZE-tag_size, end - start+1);
        file.read(buffer, bytesToRead);
        int bytesRead = file.gcount(); // Number of bytes actually read

        if (bytesRead <= 0) {
            break; // End of file or error reading
        }
        buffer[bytesRead] = '\0';
        // Prepare the segment with a sequence number (tag)
        std::string segment = std::to_string(segmentNumber++) + ":" + std::string(buffer, bytesRead);
        sendto(udpSocket, segment.c_str(), segment.size(), 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
        
        start += bytesRead;
    }

    // Close the file and the socket after sending
    file.close();
    close(udpSocket);
}


int receive_data(int udpSocket) {
    while (true) {
        char buffer[MAX_SEGMENT_SIZE];
        struct sockaddr_in clientAddr;
        socklen_t addrLen = sizeof(clientAddr);

        // Receive data
        int bytesReceived = recvfrom(udpSocket, buffer, sizeof(buffer), 0, (struct sockaddr *)&clientAddr, &addrLen);
        if (bytesReceived < 0) {
            std::cerr << "Failed to receive data\n";
            return 1;
        }

        buffer[bytesReceived] = '\0'; // Null-terminate the received data
       
        std::istringstream iss(buffer);
        std::string command, filename, start, end, ip, port;

        if (!(iss >> command >> filename >> start >> end >> ip >> port)) {
            std::cerr << "Invalid message format\n";
            return 1;
        }

        // Convert start, end, and port to integers
        int startInt = std::stoi(start);
        int endInt = std::stoi(end);
        int portInt = std::stoi(port);

        if (command == "sendFileTo") {
            send_file(filename, startInt, endInt, ip, portInt);
        } else {
            std::cerr << "Unknown command\n";
        }
    }
    // Potentially unreachable code depending on your implementation
    return 0;
}


int sender_mode(int port) {
    int udpSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udpSocket < 0) {
        std::cerr << "Failed to create socket\n";
        return 1;
    }

    struct sockaddr_in serverAddr;
    std::memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    serverAddr.sin_addr.s_addr = INADDR_ANY; // Bind to any available address

    if (bind(udpSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        std::cerr << "Failed to bind socket\n";
        close(udpSocket);
        return 1;
    }

    int r = receive_data(udpSocket);
    close(udpSocket);
    return r;
}

void receive_segments(int udpSocket, std::unordered_map<int,std::string> & fileData, const std::string& sharedFolderPath, const std::string& filename, int end,int max_segements) {
     int current_segments =1;
     int timeoutSeconds = 5;
    
    while (current_segments<=max_segements) {
        char buffer[MAX_SEGMENT_SIZE];
        struct sockaddr_in senderAddr;
        socklen_t addrLen = sizeof(senderAddr);
        
        
        fd_set readfds;
        struct timeval timeout;

        FD_ZERO(&readfds);
        FD_SET(udpSocket, &readfds);

        timeout.tv_sec = timeoutSeconds;
        timeout.tv_usec = 0;

        int activity = select(udpSocket + 1, &readfds, nullptr, nullptr, &timeout);

        if (activity == -1) {
            perror("Error in select");
            break;
        } else if (activity == 0) {
            std::cout << "Timeout: No data received within " << timeoutSeconds << " seconds\n";
            break;
        } else {
            if (FD_ISSET(udpSocket, &readfds)) {
                     int bytesReceived = recvfrom(udpSocket, buffer, sizeof(buffer), 0, (struct sockaddr *)&senderAddr, &addrLen);
        if (bytesReceived < 0) {
            
            perror("Error receiving data");
            break;
        }
        std::string receivedMessage(buffer, bytesReceived);
   
        std::cout<<receivedMessage<<"\n";
        size_t delimiterPos = receivedMessage.find(':');
        if (delimiterPos != std::string::npos) {
                std::string segmentNumberStr = receivedMessage.substr(0, delimiterPos);
                std::string segmentContent = receivedMessage.substr(delimiterPos + 1);

            int segmentNumber = std::stoi(segmentNumberStr);

            fileData.insert(std::make_pair(segmentNumber,segmentContent));

       
      }
    else {
    std::cerr << "Invalid segment format: " << receivedMessage << std::endl;
    }
            }
        }
       
        current_segments++;
    }
  
    isReceiverThreadDone = true;
    
}


void receiver_thread(int udpSocket, std::unordered_map<int,std::string> & fileData, const std::string& sharedFolderPath, const std::string& filename,int end,int max_segements) {

  
    receive_segments(udpSocket, fileData, sharedFolderPath, filename,end,max_segements);
}

int receiver_mode(char** slots, int n, std::unordered_map<int,std::string> & fileData) {
    int udpSocket;
    struct sockaddr_in receiverAddr;
    struct ifaddrs *addrs, *tmp;

    // Create UDP socket
    udpSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udpSocket < 0) {
        perror("Error opening socket");
        exit(EXIT_FAILURE);
    } 

    // Set receiver address and port
    memset(&receiverAddr, 0, sizeof(receiverAddr));
    getifaddrs(&addrs);

    for (tmp = addrs; tmp != NULL; tmp = tmp->ifa_next) {
        if (tmp->ifa_addr && tmp->ifa_addr->sa_family == AF_INET) {
            struct sockaddr_in *pAddr = (struct sockaddr_in *)tmp->ifa_addr;
            if (strcmp(inet_ntoa(pAddr->sin_addr), "127.0.0.1") != 0 && strcmp(inet_ntoa(pAddr->sin_addr), "0.0.0.0") != 0) {
                receiverAddr.sin_family = AF_INET;
                receiverAddr.sin_port = htons(8081); // Use the default port 8081
                receiverAddr.sin_addr = pAddr->sin_addr; // Store the found IP address
                break; // Stop after the first non-loopback address is found
            }
        }
    }
         int opt = 1;
        if (setsockopt(udpSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
                 perror("setsockopt");
                 // Handle error
        }
    if (bind(udpSocket, (struct sockaddr *)&receiverAddr, sizeof(receiverAddr)) < 0) {
        std::cerr << "Failed to bind socket\n";
        close(udpSocket);
        return 1;
    }
    int how_many_segments =0;
    for (int j = 0; j < n; j += 4) {
        
        int start = atoi(slots[j+2]);
        int end = atoi(slots[j+3]);
        while(start<end){
            int tag = 1 + NumDigits(start);
            int this_segment = MAX_SEGMENT_SIZE-tag;
            how_many_segments++;
            start = start + this_segment;
        }
    }

    std::thread receiver(receiver_thread, udpSocket, std::ref(fileData), sharedFolderPath, slots[(n - 3)],atoi(slots[(n-1)]),how_many_segments);
    receiver.detach(); 

    for (int i = 0; i < n; i += 4) {
        // Prepare the message: sendFileTo filename start end thisIp thisPort
        if (slots[i]=="-1")
            continue;

         int udpSocket2 = socket(AF_INET, SOCK_DGRAM, 0);
         if (udpSocket2 < 0) {
        perror("Error opening socket");
        exit(EXIT_FAILURE);
        } 
         // Set receiver address and port
        struct sockaddr_in senderAddr;
        memset(&senderAddr, 0, sizeof(senderAddr));
        senderAddr.sin_family = AF_INET;
        senderAddr.sin_port = htons(8080); // Use the default port 8080
        inet_pton(AF_INET, slots[i], &senderAddr.sin_addr);
        char message[MAX_SEGMENT_SIZE];
        std::cout<<slots[i]<<" "<<slots[i+1]<<" "<<slots[i+2]<<"  "<<slots[i+3]<<"\n";
        snprintf(message, MAX_SEGMENT_SIZE, "sendFileTo %s %s %s %s 8081", slots[(i+1)], slots[(i+2)], slots[(i+3)], inet_ntoa(receiverAddr.sin_addr)); // filename //start //end //ip//port
        // Send the message to the client at slots[i] on port 8080
        if (sendto(udpSocket2, message, strlen(message), 0, (struct sockaddr*)&senderAddr, sizeof(senderAddr)) < 0) {
            perror("Error sending message");
            exit(EXIT_FAILURE);
        }
    }
    while (!isReceiverThreadDone) {
        sleep(0.5);
    }
    isReceiverThreadDone=false;
    if (fileData.size() == how_many_segments) {
                std::string sharedFilePath = sharedFolderPath +  slots[(n - 3)]; // Use the filename provided
                std::string fileContent ="";
                std::vector<int> keys;
                for (const auto& pair : fileData) {
                    keys.push_back(pair.first);
                }
                std::sort(keys.begin(), keys.end());
                 for (const auto& key : keys) {
                    fileContent +=fileData[key];
                  }
                std::ofstream outputFile(sharedFilePath, std::ios::app);
                if (outputFile.is_open()) {
                    outputFile << fileContent;
                    outputFile.close();
                    std::cout << "File received and stored in " << sharedFilePath << std::endl;
                } else {
                    std::cerr << "Failed to open file: " << sharedFilePath << std::endl;
                }
                
        }else {
    // Mark segments already received as "-1"
    char*stringArray[n];
    for (int i = 0; i < n; i += 4) {
       
        int start = atoi(slots[i + 2]);
        int end = atoi(slots[i + 3]);
        while (start < end) {
            int tag = 1 + NumDigits(start);
            int this_segment = MAX_SEGMENT_SIZE - tag;
            if (fileData.find(start) != fileData.end()) {
                // Mark this segment as received
                std::cout<<slots[i]<<" "<<slots[i+1]<<" "<<slots[i+2]<<"  "<<slots[i+3]<<"\n";
                slots[i] = strdup("-1");
                break; // Move to the next slot
            }
            start = start + this_segment;
        }
    }

        close(udpSocket);
    return receiver_mode(slots, n, fileData);
}
    close(udpSocket);
    return 0;
 }







int main (int argc, char* argv[]) {

    sharedFolderPath = argv[1];

    if (sharedFolderPath.back() != '/') {
        sharedFolderPath += '/';
    }

    if (argc == 2){
       
        sender_mode(8080); 
    }
    else{
        std::unordered_map<int,std::string> fileData; // filename -> (expected segments, collected segments)
        receiver_mode(argv+2,argc-2,fileData);
    }

    return 0;
}