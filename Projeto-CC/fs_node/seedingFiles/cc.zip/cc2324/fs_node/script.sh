sudo ifconfig lo0 alias 192.168.1.70 up
sudo -u nunorodrigues python main.py seedingFiles2 Air-de-Nuno.home
