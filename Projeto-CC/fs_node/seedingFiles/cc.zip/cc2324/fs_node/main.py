import socket
import sys
import threading
import os
import time
import subprocess
import ast

MyFiles = {}  # mapa de ficheiros nome do ficheiro para


def set_receiver(socket_list_str, folder, file_name):
    file_path = os.path.join(folder, file_name)
    max_end = 0
    max_entry = None  # Initialize max_entry to None
    
    if socket_list_str == "":
        print("Ficheiro não existe")
        return
    
    socket_list = ast.literal_eval(socket_list_str)
    
    # Assuming MyFiles is a dictionary holding file information
    if file_name in MyFiles.keys():
        print("Ficheiro Já existe na pasta")
        return
    
    for ((address, port), (start, end)) in socket_list:
        if start == 1 and end > max_end:
            max_end = end
            max_entry = ((address, port), (start, end))  # Adjust tuple structure
            

    cmd2 = f'./sender {folder} {max_entry[0][0]} {file_name} {max_entry[1][0]} {max_entry[1][1]}'
    print(cmd2)
    if max_end != 0:
        # Function to run the C++ program and measure execution time
        start_time = time.time()  # Get the current time before executing the program
        def run_cpp_program():
            # Construct the command with four arguments and execute it
            cmd = f'./sender {folder} {max_entry[0][0]} {file_name} {max_entry[1][0]} {max_entry[1][1]}'
            subprocess.run(cmd, shell=True)

        client_thread = threading.Thread(target=run_cpp_program)
        client_thread.start()
        end_time = time.time()  # Get the current time after the program finishes
        execution_time = end_time - start_time  # Calculate execution time
        client_thread.join()
        print("Transferencia demorou: ",execution_time)


        
        
def checker(folder, socket):
    while True:
        try:
            files = os.listdir(folder)
            for file in files:
                file_path = os.path.join(folder, file)
                if os.path.isfile(file_path):
                    file_name = os.path.basename(file_path)
                    file_size = os.path.getsize(file_path)
                    MyFiles[file_name] = (file_size, file_path)  # Update MyFiles dictionary

                    # Send the information to the socket
                    message = f"regf {file_name} 1 {file_size}"
                    socket.send(message.encode())
                    socket.recv(1024).decode()

        except Exception as e:
            print(f"Error while checking folder: {str(e)}")

        # Sleep for 30 seconds
        time.sleep(30)


def client_program(folder, host):
    port = 9090  # Port used in TCP

    try:
        client_socket = socket.socket()

        client_socket.connect((host, port))
        print("SCS: Connected to", host)

    except:
        print("ERROR: Host não existe")
        return

    # register node once connected
    message = "regn"
    client_socket.send(message.encode())
    client_socket.recv(1024).decode()

    # create thread to check the folder for files
    ct = threading.Thread(target=checker, args=(folder, client_socket))
    ct.start()

    # start daemon for client-server interaction
    message = input(" -> ")
    while message.lower().strip() != 'quit':
        aux = message.split()
        client_socket.send(message.encode())
        data = client_socket.recv(1024).decode()
        print('Server response: ' + data)
        if aux[0] == "getf":
            set_receiver(data, folder,aux[1])

        message = input(" -> ")

    client_socket.close()


if __name__ == '__main__':

    if len(sys.argv) == 3:
        arg1 = sys.argv[1]
        arg2 = sys.argv[2]

    else:
        print("Please provide arguments.")
        sys.exit(1)

    # Function to run client_program in a thread
    def run_client_program():
        client_program(arg1, arg2)

    # Function to run C++ program in a thread
    def run_cpp_program():
        # Access the globally or locally defined variables directly here
        st = f'./sender {arg1}'
        subprocess.run(st, shell=True)

    # Create threads for client_program and C++ program execution
    client_thread = threading.Thread(target=run_client_program)
    cpp_thread = threading.Thread(target=run_cpp_program)

    # Start both threads
    client_thread.start()
    cpp_thread.start()
